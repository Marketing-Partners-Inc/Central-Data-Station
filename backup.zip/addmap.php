<?php
    session_start();
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit();
    } 
    
?>
<?php 
    include("includes/config.php");
    include_once('includes/header.php');
?>
<?php 
    if(
        !isset($_POST['TOPI'])  &&
        isset($_POST['new_submit']) && isset($_SESSION['new_submit']) && $_POST['new_submit']==$_SESSION['new_submit']
    ){
        if(
            (isset($_POST['api_form_id']) && !empty($_POST['api_form_id'])) && 
            (isset($_POST['key_name_count']) && !empty($_POST['key_name_count']) && (int)$_POST['key_name_count'] > 1)
        ){
            $mapping_details = filter_var_array($_POST, FILTER_SANITIZE_STRING);
            $key_name_count = (int)$mapping_details['key_name_count'];
            $api_form_id = $mapping_details['api_form_id'];
            $status = 1;
            $count = 0;
            $updated = date('Y-m-d H:i:s');
            $db_query_1  = " INSERT INTO map ( localfield, externalfield, formid, status, updated, createdby ) ";
            $db_query_2  = " VALUES ";
            while($count < $key_name_count ){
                $key_name = 'key_name_'.$count;
                $table_key = str_replace('key_name_','',$mapping_details[$key_name]);
                $table_value = $mapping_details[$mapping_details[$key_name]];
                $db_query_2  .= " ( ";
                $db_query_2 .= "'".$table_key."', '".$table_value."', ".$api_form_id.", ".$status.", '".$updated."'";
                $db_query_2 .= " )";
                if($count < $key_name_count-1){
                    $db_query_2 .= ", ";                    
                }
                $count++;
            }
            echo $db_query = $db_query_1 . $db_query_2;
        }
    }
?>
<!DOCTYPE html>
<html>
  
<head>
	<?php //include("includes/head-tag-contents.php");?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>

<?php //include("includes/design-top.php");?>
<?php //("includes/navigation.php");?>
<?php
    $curl = curl_init();
    $api_url = 'https://bigcloud.work/api/category/read.php';
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://bigcloud.work/api/category/read.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $reponse_arr = json_decode($response, true);
    //echo '<pre>'; print_r($reponse_arr );echo '</pre>';
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Maps</h1>
        </div>
    </div>    
    <div class="row">
	<div class="col-12">
        <form action="" method="POST">
			<table class="table">
				<thead>
					<tr class="form-group">
						<th style="border-bottom: 0">
							<label for="api_form_id">Select a Form</label>
							<select name="api_form_id" id="api_form_id" class="form-control">
								<?php for($count = 0; $count< count($reponse_arr['records']); $count++){ ?>
									<?php if(!empty($reponse_arr['records'][$count]['form_id'])) {?>
										<option value="<?php echo $reponse_arr['records'][$count]['form_id']; ?>"><?php echo $reponse_arr['records'][$count]['form_name']; ?></option>
									<?php  } ?>
								<?php  } ?>
							</select>	                            
						</th>
					</tr>
				</thead>
            </table> 
            <table class="table">
                <thead>
                    <tr>
                        <th>Map this Field <span class="pl-2">&#9660</span></th><th>To This External Field <span class="pl-2">&#9660</span></th>
                    </tr>
                </thead>
				<tbody>
				<?php 
                    $count = 0;  
                    $count_substract = 0;  
					$result = mysqli_query($link, "SHOW COLUMNS FROM alldata FROM web1_cloud") or die("mysql error");	
					while($column = mysqli_fetch_array($result)) {
                         if($column['Field'] != 'id' && $column['Field'] != 'formid'){
				?>
					<tr class="form-group">
						<th style="max-width: 100px;">
                            <label for="key_name_<?php echo $column['Field']; ?>"><?php echo $column['Field']; ?></label>
                        </th>
						<td>
							<select name="key_name_<?php echo $column['Field']; ?>" id="key_name_<?php echo $column['Field']; ?>" class="form-control form_fields">
								<option value="">Select an option</option>
							</select>
                            <input type="hidden" name="key_name_<?= $count; ?>" id="key_name_<?= $count; ?>" value="key_name_<?php echo $column['Field']; ?>">
						</td>
					</tr>
			<?php $count++; }else{$count_substract++;} } ?>
			</tbody>
			</table>
            <input type="hidden" name="key_name_count" id="key_name_count" value="<?= $count; ?>">
            <?php   $new_submit=rand();   $_SESSION['new_submit']=$new_submit;  ?>
            <input type="hidden" value="<?php echo $new_submit; ?>" name="new_submit" />   
	   </form> 
   </div>
   </div>
</div>
</body>
<script>
/**************Code 1************/
$(document).ready(function(){
    
    var old_url = $('.third').text(); var new_url;
    initialize_url();
    $('input[type="checkbox"]').on('change', function(){
        var this_check = this;
            var counter = 1;
            $('input[type="checkbox"]').each(function(){
                if((this.checked)) {
                    if(counter == 1){
                         new_url = old_url + '?';
                    }
                     
                    new_url = new_url + $(this).parent().find('input[type="text"]').attr("name") + '='+ $(this).parent().find('input[type="text"]').val() + '&';
                    counter++;
                }
            })
            if(counter==1){new_url = old_url + '?';}
            $('.third').html(new_url);
    })
})
function initialize_url(){
        var old_url = $('.third').text(); var new_url; var counter = 1;
            $('input[type="checkbox"]').each(function(){
                if((this.checked)) {
                    if(counter == 1){
                         new_url = old_url + '?';
                    }
                     
                    new_url = new_url + $(this).parent().find('input[type="text"]').attr("name") + '='+ $(this).parent().find('input[type="text"]').val() + '&';
                    counter++;
                }
            })

            $('.third').html(new_url);
}
/**************Code 2************/
    var api_url = 'https://bigcloud.work/api/category/read.php';
    fetch(api_url)
        .then(
            res => res.json()
        ).then(
            (response) => {
                var response_html = '';
            for(var i = 0; i < response.records.length ; i++){
                response_html = response_html + '<option value="'+ response.records[i].form_id + '">'+ response.records[i].form_name + '</option>'
            }
            $('#id_of_field').html(response_html);
    }
    ).catch(err => console.error(err));
</script>
<script>
/**************Code 3************/
function fetch_form_fields_for_oldman(form_id){
            if(form_id){
                $.ajax({
                type: "POST",  
                dataType: 'json', 
                url: "includes/api.php",
                data: {form_id: form_id},
                success: function(response) {
                     var response_html = '<option value="">Select an option</option>';
                    if(response){
                        for(var i = 0; i < Object.keys(response.form_fields[0]).length ; i++){
                            response_html = response_html 
                                            + '<option value="'
                                            + Object.keys(response.form_fields[0])[i] 
                                            + '">'+ Object.keys(response.form_fields[0])[i]
                                            + '</option>';
                        }
                        $('.form_fields').html(response_html);
                    }
                }
            });  
    }
}
$(document).ready(function(){
    var form_id = parseInt($('#api_form_id').val());
    fetch_form_fields_for_oldman(form_id);
    $('#api_form_id').on('change', function(){
        $('#form_fields').html('');
        var form_id = parseInt($('#api_form_id').val());
        fetch_form_fields_for_oldman(form_id);
    })
})
</script>
<script>
/**************Code 4************/
</script>
</html>
