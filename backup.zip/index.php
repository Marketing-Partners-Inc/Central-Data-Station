<?php
    session_start();
    header("location: welcome.php");
    exit;
?>